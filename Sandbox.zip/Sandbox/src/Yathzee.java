import nl.saxion.app.SaxionApp;
import nl.saxion.app.interaction.KeyboardEvent;
import nl.saxion.app.interaction.MouseEvent;

public class Yathzee extends Screen{
    @Override
    public void keyboardEvent(KeyboardEvent keyboardEvent, Application application) {

    }

    @Override
    public void mouseEvent(MouseEvent mouseEvent, Application application) {

    }

    @Override
    public void run() {

    }

    @Override
    public void init(Application application) {
        SaxionApp.clear();
    }
}
